<!DOCTYPE html>
<html>
<body>

<?php
$txt = "Books !!";
echo "I love $txt!";
?>

</body>
</html>
